"""Replay the pinned link and mutate only memory; never write sealed artifacts."""
import hashlib
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[3]
PACKET = ROOT / "docs/evidence/flight-demo/2026-10-27-m2-min-rebuild/target-1793158803095519000"
SPEC = importlib.util.spec_from_file_location("m2rb_startup", ROOT / "tools/flight_demo/m2_rebuild/startup_check.py")
CHECKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECKER)


class Startup(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.disassembly = (PACKET / "UNADMITTED.disassembly").read_text()
        cls.symbols = (PACKET / "UNADMITTED.symbols").read_text()
        cls.inventory = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in PACKET.iterdir() if p.is_file()}

    def test_normalized_boundary_is_first_stack_instruction(self):
        result = CHECKER.check(self.disassembly, self.symbols)
        self.assertEqual(result["normal_entry_ordering"], "PASS")
        self.assertEqual(result["runtime_startup_admission"].split(";")[0], "UNPROVEN")

    def test_earlier_stack_initialization_rejected(self):
        modified = self.symbols.replace("00002078 00000000 T __do_init_stack", "00002076 00000000 T __do_init_stack")
        with self.assertRaisesRegex(ValueError, "precedes"):
            CHECKER.check(self.disassembly, modified)

    def test_bypassed_entry_rejected(self):
        modified = self.symbols.replace("00002017 00000000 T _start", "00002078 00000000 T _start")
        with self.assertRaisesRegex(ValueError, "bypasses"):
            CHECKER.check(self.disassembly, modified)

    def test_wrong_cpu_port_rejected(self):
        modified = self.disassembly.replace("lda\t#$35", "lda\t#$34", 1)
        with self.assertRaisesRegex(ValueError, "CPU-port"):
            CHECKER.check(modified, self.symbols)

    def test_wrong_io_map_rejected(self):
        modified = self.disassembly.replace("lda\t#$44", "lda\t#$64", 1)
        with self.assertRaisesRegex(ValueError, "initialization differs"):
            CHECKER.check(modified, self.symbols)

    def test_missing_map_rejected(self):
        modified = self.disassembly.replace("map\n", "clc\n", 1)
        with self.assertRaisesRegex(ValueError, "prefix differs"):
            CHECKER.check(modified, self.symbols)

    def test_zz_sealed_packet_preserved(self):
        current = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in PACKET.iterdir() if p.is_file()}
        self.assertEqual(current, self.inventory)


if __name__ == "__main__":
    unittest.main()
