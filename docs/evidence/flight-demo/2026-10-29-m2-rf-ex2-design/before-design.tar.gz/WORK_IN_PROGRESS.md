# Work in Progress

- **Status: READY FOR REVIEW.**
- **Task:** Banked-renderer Build Intent `65AERO-M2-BANK-INTENT-1`, planning only, branch `codex/65aero-m2-banked-renderer-intent` from verified main `b20f91cb8023ea02e33d5fec6870026023bd8fbf`.
- **Plan:** [Founder decisions BR-D1–BR-D6](docs/plans/65AERO_M2_BANKED_RENDERER_BUILD_INTENT.md). All pending. Recommend bounded current-source contract/budget design, including a proposed development-only RF-EX2; no implementation authorization.
- **Finding:** Actual 8,264-byte deficit cannot be closed by the approved 8 KiB bank alone. At ideal occupancy, 16-byte signature and 363-byte minimum resident data leave at least 451 bytes plus all other resident overhead to recover. Historical 2,199/1,836 allowances do not apply to this baseline.
- **Admission:** Existing capacity preflight FAIL for relocation alone; proposed 16 KiB exception and current-source fit remain UNPROVEN. Resident ceiling 24,575, precision, stacks, reserve zero and runtime disablement remain unchanged.
- **Preservation:** Source baseline, generated files, sealed successes/failures, other worktrees and unrelated paths retained. Historical 22/15 recovery and eight NOT VERIFIED Git-worktree tiers unchanged.
- **Next:** Founder disposition of this plan; do not begin banking or optimization automatically.
- **Boundary:** No implementation, relink, Xemu, D81, SD, physical testing or publication.
