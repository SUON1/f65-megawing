# Work in Progress

- **Status: READY FOR REVIEW.**
- **Task:** RF-EX2 16 KiB bank design/budget investigation, approved BR-D1–BR-D6; branch `codex/65aero-m2-banked-renderer-intent`, main base `b20f91cb8023ea02e33d5fec6870026023bd8fbf`.
- **Decision packet:** [Existing RF feasibility contract, revision 4](docs/plans/65AERO_M2_RESIDENCY_FEASIBILITY.md#rf-ex2--current-source-design-and-budget-investigation). RF-EX2 remains proposed; no implementation or bank admission.
- **Budget:** Reference32,839/24,575, deficit8,264, reserve0. Current optimistic role removal8,625: distinct363 data fails by2 before other costs. Proposed existing Platform readback lease leaves253 bytes for all remaining resident overhead, whose upper bounds are unknown; no fit PASS.
- **Ownership/workspace:** Current arena demand0/16,384 with renderer676 resident. Proposed staging overlaps4,096 bytes of retained audio cache. Current oversized PRG overlaps landing by8,264; requires a new fitting link, never overlay. Whole-program stacks/service remain UNPROVEN.
- **Preservation:** Historical RF arithmetic, prior planning receipts, sealed packets, unrelated paths and source/generated files unchanged; pre-edit design files archived. Historical22/15 recovery and eight NOT VERIFIED Git-worktree tiers retained.
- **Next:** Founder review of failed/unclosed budget and explicit staging conflict. After acceptance, publish/CI/merge/verify main before a separate authorized branch. No automatic cost probe, bank prototype or optimization.
- **Boundary:** No bank implementation, target relink, execution, Xemu, D81, SD, physical testing or publication in this task.
