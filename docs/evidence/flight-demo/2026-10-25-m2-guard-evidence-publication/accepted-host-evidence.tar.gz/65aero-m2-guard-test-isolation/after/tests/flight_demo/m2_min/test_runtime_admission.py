"""Negative startup/CFG/clock-guard regressions for bounded MIN admission."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[3]
TOOLS = ROOT/'tools/flight_demo/m2_min'
PACKET = ROOT/'docs/evidence/flight-demo/2026-10-25-m2-runtime-admission'
REFERENCE = ROOT/'docs/evidence/flight-demo/2026-10-24-m2-q46-packing/candidate/MINIMUM.disassembly'


def module(name):
    spec = importlib.util.spec_from_file_location(name,TOOLS/(name+'.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


startup = module('startup_admission')
stack = module('stack_admission')
cycles = module('cycle_admission')


class RuntimeAdmissionTests(unittest.TestCase):
    def _sealed_packet(self):
        inventory = (PACKET/'inventory.json').read_bytes()
        expected = json.loads(inventory)
        expected['inventory.json'] = hashlib.sha256(inventory).hexdigest()
        actual = {str(path.relative_to(PACKET)):hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in PACKET.rglob('*') if path.is_file()}
        self.assertEqual(actual, expected, 'sealed runtime evidence must match its inventory')
        return actual

    def setUp(self):
        self.packet_before = self._sealed_packet()

    def tearDown(self):
        self.assertEqual(self._sealed_packet(), self.packet_before,
                         'regressions must preserve the original sealed inventory')

    def test_corrected_object_state_and_original_failure(self):
        result = startup.check((PACKET/'startup-object.disassembly').read_text())
        self.assertEqual(result['hardware_sp'],0x1ff)
        self.assertEqual(result['z_at_barrier'],0)
        with self.assertRaises((ValueError,KeyError)):
            startup.check(REFERENCE.read_text(),linked=True)

    def test_missing_z_reset_fails_before_c_admission(self):
        text = (PACKET/'startup-object.disassembly').read_text()
        text,number = re.subn(r'a3 00(\s+)ldz\s+#\$0\b',r'a3 0f\1ldz #$f',text,count=1)
        self.assertEqual(number,1)
        with self.assertRaisesRegex(ValueError,'flag/B/Z'):
            startup.check(text)

    def test_port_and_stack_prerequisites_fail_closed(self):
        text = (PACKET/'startup-object.disassembly').read_text()
        for old,new in [('stx\t$0 ','stx\t$1 '),('see\n','kil\n')]:
            with self.subTest(mutation=old):
                changed = text.replace(old,new,1)
                self.assertNotEqual(changed,text)
                with self.assertRaises(ValueError):
                    startup.check(changed)

    def test_whole_reference_stack_and_interrupts(self):
        result = stack.check(REFERENCE.read_text())
        self.assertEqual(result['hardware_total_bytes'],50)
        self.assertEqual(result['software_dynamic_bytes'],127)
        self.assertEqual((result['irq_bytes'],result['nmi_bytes']),(8,4))
        self.assertFalse(result['main_returns'])

    def test_unknown_reachable_instruction_is_not_neutral(self):
        text = REFERENCE.read_text().replace('\ttsy\n','\tkil\n',1)
        with self.assertRaisesRegex(ValueError,'unrecognized instruction'):
            stack.check(text)

    def test_parser_does_not_bridge_missing_instruction(self):
        code = '00001000 <main>:\n 1000: a9 00  lda #$0\n 1004: 60  rts\n'
        with self.assertRaisesRegex(ValueError,'missing instruction'):
            stack.shared.check(code)
        with self.assertRaisesRegex(ValueError,'unparsed instruction'):
            stack.shared.parse('00001000 <main>:\n 1000: 02  .byte $02\n')

    def test_unknown_timing_loops_and_instructions_fail_closed(self):
        timings = (PACKET/'public-sources/cpu65_mega65_timings.h').read_text()
        for code,message in [
            ('00001000 <main>:\n 1000: ea  nop\n 1001: 80 fd  bra $1000\n','loop bounds'),
            ('00001000 <main>:\n 1000: 02  kil\n 1001: 60  rts\n','unrecognized timed')]:
            with self.subTest(message=message),self.assertRaisesRegex(ValueError,message):
                cycles.Costs(cycles.Program(code),timings).function('main')

    def _guard_source(self):
        main = (ROOT/'src/diagnostics/m2_min/main.c').read_text()
        guard = main[main.index('static uint8_t can_dispatch'):main.index('static void stop')]
        return '''#include <stdint.h>
#include <assert.h>
#include "service_bounds.h"
static uint32_t simulated_now;
static uint8_t simulated_fault;
static uint32_t m1_platform_now(void) { return simulated_now; }
static uint8_t m1_platform_fault(void) { return simulated_fault; }
volatile uint32_t m2_min_service_counts[8];
''' + guard + '''
int main(void)
{
    for (uint8_t slot = 0; slot < 8; ++slot)
    {
        simulated_fault = 0;
        simulated_now = 100;
        m2_min_service_counts[slot] = 0;
        assert(!can_dispatch(slot, 10000));
        m2_min_service_counts[slot] = 100;
        assert(can_dispatch(slot, 201));
        assert(!can_dispatch(slot, 200));
        assert(!can_dispatch(slot, 99));
        simulated_now = 0;
        simulated_fault = 3;
        assert(!can_dispatch(slot, 10000));
        simulated_fault = 0;
        simulated_now = M2_MIN_CLOCK_LIMIT_COUNTS;
        assert(!can_dispatch(slot, simulated_now + 10000u));
    }
    return 0;
}
'''
    def _run_guard(self, source):
        # Historical packet members are inputs only, on every exit path.
        with tempfile.TemporaryDirectory(prefix='f65-m2-guard-') as directory:
            output = Path(directory)
            path = output/'guard-regression.c'
            path.write_text(source)
            binary = output/'guard-regression.host'
            args = ['/usr/bin/clang','-std=c11','-Wall','-Wextra','-Wconversion','-Werror',
                    '-fsanitize=address,undefined','-I'+str(ROOT/'src/diagnostics/m2_min'),
                    str(path),'-o',str(binary)]
            result = subprocess.run(args,capture_output=True,text=True)
            (output/'guard-build.txt').write_text(result.stdout+result.stderr)
            self.assertEqual(result.returncode,0,
                             'guard compile exit '+str(result.returncode)+': '+result.stdout+result.stderr)
            run = subprocess.run([str(binary)],capture_output=True,text=True)
            (output/'guard-result.txt').write_text(run.stdout+run.stderr)
            self.assertEqual(run.returncode,0,
                             'guard run exit '+str(run.returncode)+': '+run.stdout+run.stderr)

    def test_actual_guard_faults_limits_and_slack(self):
        self._run_guard(self._guard_source())

    def test_failed_guard_build_preserves_sealed_packet(self):
        source = self._guard_source()+'\n#error intentional guard build failure\n'
        with self.assertRaisesRegex(AssertionError, 'guard compile exit [1-9]'):
            self._run_guard(source)

    def test_failed_guard_run_preserves_sealed_packet(self):
        source = self._guard_source().replace('assert(can_dispatch(slot, 201));',
                                             'if (can_dispatch(slot, 201))\n'
                                             '        {\n'
                                             '            return 17;\n'
                                             '        }')
        with self.assertRaisesRegex(AssertionError, 'guard run exit 17:'):
            self._run_guard(source)


if __name__ == '__main__':
    unittest.main()
