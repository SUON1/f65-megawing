"""Read-only correction/preservation checks; print results, never rewrite evidence."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

PACKET = Path(__file__).resolve().parent
ROOT = PACKET.parents[3]
ORIGINAL = ROOT/'docs/evidence/flight-demo/2026-10-25-m2-runtime-admission'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    before = json.loads((PACKET/'before.json').read_text())
    expected = {'WORK_IN_PROGRESS.md','tests/flight_demo/m2_min/test_runtime_admission.py'}
    changed = set()
    for name,old in before['files'].items():
        path = ROOT/name
        if path.is_symlink():
            assert old == dict(kind='symlink',target=str(path.readlink())),name
        elif sha(path) != old['sha256'] or path.stat().st_size != old['bytes']:
            changed.add(name)
    assert changed == expected,changed
    for name in expected:
        assert sha(ROOT/name) == sha(PACKET/'after'/name),name
        assert sha(PACKET/'before'/name) == before['files'][name]['sha256'],name
    names = {name for name in subprocess.check_output(
        ['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0') if name}
    added = names-set(before['files'])
    assert all(name.startswith(str(PACKET.relative_to(ROOT))+'/') for name in added)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip() == before['head']
    assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT).decode().strip() == before['branch']
    assert sha(ORIGINAL/'inventory.json') == before['inventory_sha256']
    inventory = json.loads((ORIGINAL/'inventory.json').read_text())
    assert len(inventory) == before['sealed_members'] == 294
    assert {str(path.relative_to(ORIGINAL)) for path in ORIGINAL.rglob('*') if path.is_file()} == set(inventory)|{'inventory.json'}
    assert all(sha(ORIGINAL/name) == pin for name,pin in inventory.items())
    candidate = json.loads((ORIGINAL/'candidate-admission.json').read_text())
    assert all(sha(ROOT/name) == pin for name,pin in dict(candidate['exact_source_pins'],**candidate['new_input_pins']).items())
    preserved = json.loads((ORIGINAL/'preservation-before.json').read_text())
    spec = importlib.util.spec_from_file_location('readonly_reconcile',ROOT/'tools/flight_demo/m2_min/reconcile.py')
    reconcile = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reconcile)
    for folder,identity in preserved['prior_worktrees'].items():
        assert reconcile.snapshot(Path(folder)) == identity,folder
    members = 0
    for name,identity in preserved['historical_inventories'].items():
        path = Path(name)
        assert sha(path) == identity['sha256'],name
        entries = json.loads(path.read_text())
        assert len(entries) == identity['members']
        assert all(sha(path.parent/member) == pin for member,pin in entries.items()),name
        members += len(entries)
    for name,identity in preserved['historical_raw_artifacts'].items():
        path = Path(name)
        assert sha(path) == identity['sha256'] and path.stat().st_size == identity['bytes'],name
    assert all(sha(ROOT/name) == pin for name,pin in preserved['generated_memory'].items())
    assert str((ROOT/'toolchain/runtime').readlink()) == preserved['sdk_symlink']
    test = ROOT/'tests/flight_demo/m2_min/test_runtime_admission.py'
    ast.parse(test.read_text(),filename=str(test))
    ast.parse(Path(__file__).read_text())
    log = (PACKET/'min-regressions.txt').read_text()
    assert 'Ran 13 tests' in log and log.rstrip().endswith('OK')
    for case in ['test_actual_guard_faults_limits_and_slack',
                 'test_failed_guard_build_preserves_sealed_packet',
                 'test_failed_guard_run_preserves_sealed_packet']:
        assert re.search(r'^'+case+r'.* \.\.\. ok$',log,re.M),case
    for target in re.findall(r'\]\(([^)]+)\)',(PACKET/'README.md').read_text()):
        assert (PACKET/target).exists() or target in {'validation.json','inventory.json'},target
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    print(json.dumps(dict(status='PASS; READY FOR REVIEW',changed_existing=sorted(changed),
        original_paths=len(before['files']),unchanged_existing=len(before['files'])-len(changed),
        minimum_tests=13,passing_guard=True,expected_compile_failure=True,expected_guard_exit=17,
        original_sealed_members=294,original_inventory_sha256=before['inventory_sha256'],
        prior_worktrees=len(preserved['prior_worktrees']),historical_inventories=31,
        historical_members_including_runtime=members+294,raw_artifacts=151,generated_memory=46,
        unrelated_entries=len(preserved['unrelated_entries']),sdk_symlink='unchanged',
        target_sources_and_artifacts='unchanged',target_relinks=0,xemu_d81_sd_physical='NOT RUN',
        resident_bytes=candidate['resident_bytes'],resident_limit=24575,deficit_bytes=candidate['deficit_bytes'],
        compiler_static_scratch_bytes=77,reserve=0,publication='NONE'),indent=2))


if __name__ == '__main__':
    main()
