# Guard-test evidence isolation — P2 correction

25 October 2026. **READY FOR REVIEW.** Authority: the founder's “Build it”
instruction on the review comment for `test_runtime_admission.py:113–120`.
This is a host-test correction on the existing
`codex/65aero-m2-minimal-runway-renderer` branch, base
`44e4c09050a7d3282ea7c3e577d6cdd9124f2a18`.

The prior test wrote its generated C source, executable and logs directly into
the sealed runtime-admission packet. It now uses `TemporaryDirectory`, whose
scope also covers compilation or execution failure. Diagnostics remain in the
test assertion output; no historical member is an output destination.

Each runtime-admission test checks the complete packet file set, every member
hash and the inventory file's own hash before and after execution. The normal
ASan/UBSan guard regression remains, and two new regressions exercise a deliberate
compilation failure and a deliberate guard-program exit 17. Both must observe
the expected failure while preserving the original packet. These controlled
negative cases are passing host regressions, not failed target-admission gates.

Executed:

```text
python3 -B -m unittest discover -s tests/flight_demo/m2_min -p 'test_*.py' -v
git diff --check
```

**13 tests PASS**; [unaltered command output](min-regressions.txt).
The successful guard retains `-fsanitize=address,undefined` and its existing
compiler warning flags. No target compiler or linker was invoked. The independent
final scope, source-identity and preservation reconciliation is recorded in
[validation.json](validation.json); the [inventory](inventory.json) seals this
new correction packet separately.

Changed existing paths are only
`tests/flight_demo/m2_min/test_runtime_admission.py` and `WORK_IN_PROGRESS.md`.
Their original bytes are retained under `before/`; corrected bytes and the
focused diff are retained alongside this record. All other existing paths,
historical inventories, predecessor worktrees, generated/memory paths, SDK
symlink and 20 unrelated entries are preserved.

The original runtime-admission packet still has **294 members**, with inventory
SHA-256 `d5fce59c011225643d27d884454c7b7982e7a99dfbd4e1af598a4a4fb200a245`.
Its original report, test source snapshot, host executable, logs, failures and
Xemu observations were not rewritten. The corrected test lives in the active
test tree; archived source remains historical input, not a rerun destination.

The candidate PRG remains
`10c6b083bd37392b8177d3211035a76c599894aa46bb11ff4a18851e97dab6e1`.
Resident usage remains **26,750 / 24,575**, deficit **2,175**, static compiler
scratch **77**, reserve **0**. Those are preserved measurements, not a new
link or memory admission. Prior startup, stack, service and emulator results
retain their exact profile and evidence boundaries.

No target source, guard behavior, public ABI, numeric precision, memory ownership
or limit changed. Registers/clobbers, CPU-visible and physical memory, MAP/base
page, DMA, target timing/deadlines and IRQ/NMI effects are **not applicable** to
this host-test correction. No banking, optimization, Xemu, D81, SD-media,
physical test, commit, push or PR work occurred. Founder review is next.
