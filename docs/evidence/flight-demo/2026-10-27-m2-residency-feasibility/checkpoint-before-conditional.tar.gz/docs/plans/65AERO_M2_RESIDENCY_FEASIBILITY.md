# M2 recovery exit and residency feasibility

27 October 2026. Identity: **65AERO-M2-RESIDENCY-FEASIBILITY-1**.
**READY FOR REVIEW — STOP AT REQUIRED DESIGN DECISIONS.**
This is a newly authored development contract proposal, not adoption of the
incomplete historical packet and not a banked implementation.

## Baseline and disposition

GitHub main was freshly fetched and independently checked with ls-remote:
`af3b0913c4b73eb6b8add638fb88bdbbae158036`.
Its exact push [CI run 40259907202](https://github.com/SUON1/f65-megawing/actions/runs/40259907202)
is completed/success. The initially clean new branch is
`codex/65aero-m2-residency-feasibility`, based directly on that commit in a
durable Developer checkout. The original dirty checkout was not switched,
reset, cleaned or repurposed. No damaged checkout supplies the source baseline.

The founder's Recovery Exit directive is the Build Intent: end recovery as a
prerequisite; prepare a small current contract; reconcile the budget; prototype
only if legal and fully costed; stop at a required decision or failed gate.
“Cost” clarification concerns model tokens and money, not target byte or safety
limits. No further APFS, snapshot, Trash or historical-worktree search occurred.

The former 37-member adoption packet remains **incomplete and unadopted**:
22 members were previously SHA-256 verified; 15 were not verified recoverable.
Its retained inventory SHA-256 is
`1e932efe541468afce20081b9654186b457c458b24d70df992a6c911b2233447`.
Those are historical findings, not a new full-packet preservation PASS.
Eight historical checkouts remain **NOT VERIFIED at the Git-worktree tier**;
available byte-level findings do not establish ancestry. No missing files,
metadata, logs, timestamps or test results were reconstructed. The old
MAP-2/BOOT-2/CODEBANK-2 drafts inform this proposal only. Their exact informing
identities are recorded in the [calculation](../evidence/flight-demo/2026-10-27-m2-residency-feasibility/accounting.json);
no private journal or recovered packet contents are copied into this checkpoint.

## Authority and the required decisions

Inspected authority: [manifest](../../spec/manifests/spec-corpus.json);
[Main v1.8](../../spec/core/F65_Main_Concept_v1.8_APPROVED_AMENDMENT.md) and
incorporated v1.7 §§5.1–5.3;
[Runtime v1.2 candidate](../../spec/core/F65_Runtime_v1.2_APPROVED_CANDIDATE_AMENDMENT.md)
and its incorporated base §§6.1–6.6; [Graphics v2.1](../../spec/subsystems/F-65_Megawing_Graphics_White_Paper_v2.1.pdf)
§9 (pp. 11–12); [Phase 1 plan](65AERO_PHASE1_ENTRY_AND_DEVELOPER_FLIGHT_PLAN.md);
[M2 geometry intent](65AERO_M2_REGISTERED_RUNWAY_CAMERA_BUILD_INTENT.md);
[M2 PR2 intent](65AERO_M2_PR2_BUILD_INTENT.md); existing
[full ledger](../../memory/m2-full-ledger.json),
[PR1 ledger](../../memory/m2-pr1-ledger.json),
[platform registry](../../interfaces/f65_platform_abi.json5),
[published evidence](../reports/M2_GUARD_EVIDENCE_PUBLICATION.md),
and the live M1 Platform/build seams.

Main and Runtime assign physical $048000–$04FFFF to renderer workspace.
Graphics binds that range to vertices/buckets/spans/staging/occlusion and says
renderer code shares the resident code ceiling. The integrated M2 PR2 intent
also requires code below $8000 and forbids automatic bank expansion.
A new bank cannot be made legal merely by naming it Graphics-owned.
Runtime's protected-MAP rule is compatible in principle with a private gateway,
but the historical registry's mapped-scope prohibitions and copy allowlists
do not themselves admit executable bank calls or the new boot destinations.

| ID | Exact founder decision requested | Recommendation |
| --- | --- | --- |
| RF-D1 | Approve a coordinated, development-only Main/Runtime/Graphics exception permitting one immutable 8 KiB Graphics code bank at physical [$048000,$04A000), with only private execution through CPU [$8000,$A000), leaving [$04A000,$050000) as Graphics workspace? | **Yes for a versioned contract-adoption increment.** Preserve the $2001–$7FFF resident ceiling, all existing public layouts/owners, zero reserve and FULL requirements. Keep code charged to Graphics across both domains; this is not extra resident capacity. |
| RF-D2 | Approve the protected private gateway contract below, including two ordinary-C entry roles, a closed private resident-helper closure, IRQ masking for one admitted quantum, and signature verification on every invocation? | **Yes, conditionally on exact linked ABI/MAP/stack/service qualification.** No public API, callback, MAP ownership, numerical format or simulation-order change. No execution while any required proof is unknown. |
| RF-D3 | Approve the reset-only boot/load leases below: bank-0 [$008000,$00A000) from PRG load time and ResourceManager staging [$050000,$052000), with Platform as sole loader and no concurrent owners? | **Yes for the same versioned contract increment.** Require load/identity verification, complete landing retirement, immutable run-bank publication and fail-closed lockout. No historical allowlist is silently widened; no D81/SD transport or runtime reload is admitted. |

These decisions have not been made by this checkpoint. The old RL approvals
authorized preparation of an unadopted packet; they do not integrate its drafts.
The founder explicitly requires a stop at a design decision. No target
prototype, source reconstruction or speculative optimization starts here.

## RF-CODE-1 — proposed ownership and lifetime contract

Keep the nine-segment minimum selection [0,1,2,3,4,5,7,11,15] from the unchanged
17-segment Environment fixture. Retain sky/ground on the common camera horizon,
a controllable diagnostic camera, numeric telemetry, ALTITUDE and AIRSPEED
NOT IMPLEMENTED, and NON-FLIGHT DIAGNOSTIC. No omitted registered HUD cues,
ranked labels, physics, fake motion, weapons or AI are enabled.

The run bank is one immutable Graphics allocation, physical [$048000,$04A000).
It is an alias at CPU [$8000,$A000) only inside a protected scope.
Platform alone loads/selects/restores it. No nested bank, reload or runtime
writer is permitted. Only transform-step and project-step roles enter it.
Keep their begin functions, public wrappers, constants/tables/font, cached
geometry, continuations, input/result objects and compiler scratch resident.
Keep existing numerical precision and independent oracle tolerances.

The reference nine-body membership is in accounting.json. Its resident helper
closure is limited to __memset, __modhi3, __mulsi3, __umodhi3,
m2_min_bytes_any/clear/copy and m2_min_word_add/compare/half/increment/left/
negate/negative/subtract. Link reachability must prove the actual closure.
No guessed indirect entry, unlisted helper, literal pool, ROM call, MMIO,
callback, DMA, clock read or yield is allowed inside the scope.
Both entry offsets must identify their exact linked instruction boundaries
after the header, within the actual image length. A range check alone is
insufficient.

No bank pointer escapes. Prepared geometry is built once per captured
generation, retained across bounded continuations and invalidated on cancellation
or camera/generation change. Check coherence before entry and after canonical
exit. Immutable snapshots and complete-frame publication remain unchanged.
Bank code/data and resident lifetimes are charged separately; no borrowed
stack, display slack, Color RAM, ROM backup or protected reserve is allowed.

## RF-MAP-1 — proposed per-invocation gateway contract

Require canonical entry, exact READY identity, retired boot leases, valid near
spans, no active mapping, no sticky fault and sufficient admitted deadline slack.
Platform alone owns the gateway, expected identity and mapping state.

For **every bank-call invocation**, including an already selected/loaded bank:

1. Validate entry conditions and save the declared context in owned resident
   storage. Save original P and mask IRQs before the first mutable MAP operation.
2. Perform any required bank selection/MAP/EOM.
3. Through volatile reads and an admitted compiler barrier, read and compare the
   expected 16-byte bank signature in the selected execution window.
4. Only a successful verification for this invocation permits the typed bank
   entry. A prior successful verification never authorizes a later call.
5. On missing, incorrect, changed or unreadable signature, execute no banked
   instruction. Restore canonical state, invalidate eligibility, set a sticky
   fault and lock out future dispatch until reset. If safe restoration cannot
   be established, remain in a protected resident terminal sink; do not return
   through an uncertain mapping.

Verification belongs to the protected gateway, never Graphics callers.
The existing informing wire format is retained as a proposal: 16 bytes consisting
of ASCII 65M2RUN2 and the first eight bytes of the expected build ID. This
checkpoint invents no new signature format or public ABI. A matching signature
is identity checking, not whole-bank integrity, hardware write protection or
proof of the physical address selected. Same-build stale staging aliases need
independent spatial/MAP qualification. If readable mapping or a safe read cannot
be established, admission is UNPROVEN; do not pretend an unreadable bus always
raises a detectable exception.

Private enter/leave helpers take no arguments, return status in A, preserve
X/Y/Z/B, logical compiler pseudo-registers $02–$21 and both stack pointers.
A aliases Q's low byte, so independent Q preservation is not asserted.
Banked C bodies use the pinned ordinary C ABI; no guessed assembly parameter
ABI is introduced. Preserve the body result before leave clobbers A.
Insufficient pre-entry slack may defer without body work; permanent identity,
range, signature or restoration failure may never masquerade as continuing or
completed work.

Restore zero MAP masks/offsets and both megabyte selectors, finish EOM, restore
B=$02, Z=0, E=1, CPU-port DDR=$2F/data=$35, admitted ROM/I/O state (including
D030=$44 where required), page-1 hardware stack, $C000–$CFFF software stack,
resident vectors and original P before public return/yield or clock work.
The proposed offset $040000 and block-4 selection parameters A=$00, X=$00,
Y=$00, Z=$14 remain derived design values, not executed qualification.

One scope contains at most one bounded body quantum plus entry, per-call
verification and restoration. IRQ masking is charged for that entire interval.
The unmaskable NMI path must remain resident, never touch MAP/bank/DMA/C state,
preserve return to the same mapping and retain sticky interference. Include its
legal races and fault exits in the exact control-flow proof. A nested call
cannot clear an outer token or return into an unmapped caller.

## RF-BOOT-1 — proposed load and content contract

Use one reset-loaded self-contained uncompressed PRG at $2001.
Distinguish bank payload LMA [$008000,$00A000), CPU VMA [$8000,$A000) and
physical run destination [$048000,$04A000). The landing lease begins at load
time, before C or an operational ResourceManager. It is not runtime capacity.

Before BSS/data/compiler-dependent access, prove canonical MAP/megabyte/B/Z,
CPU port/ROM/I/O, page-1 stack and interrupt policy from actual entry disassembly
and an independent control-flow check. Main's M1 startup cannot substitute for
the missing corrected minimum-renderer startup. Loader, descriptor, scratch,
vectors and both stacks must be outside the landing/mapped window.

After C initialization and the admitted Platform/ROM-backup/clock lifecycle,
but before first tick release, validate the pinned source/tool/command identity,
descriptor, exact length, entry roles and CRC-32/ISO-HDLC. Retain the informing
64-byte descriptor and 16-byte signature format; exact wire offsets require
the new adoption's single generated source, not handwritten public duplicates.

Use the exclusive [$050000,$052000) staging lease, checked full spans and
1–255-byte CPU-copy chunks. Four N-byte passes are landing→staging,
staging→resident readback/CRC, staging→run bank and run bank→readback/CRC.
At N=8192 this is 132 chunks, 32768 copied bytes and 16384 CRC-processed bytes.
Separately zero/read back all 8192 landing bytes before retiring the lease.
Only then release staging and publish READY after sticky-fault checks.
Stale staging bytes confer no runtime access. No retry, fallback or repair.

A new typed fixed-class facade must prove the unchanged backend's mailbox,
base-page, copy-span, stack and interference requirements; neither cfcopy nor
a historical wrapper gains new permissions by implication. No DMA submission
is introduced. Preserve protected ROM backup [$08000000,$08020000).
Boot failure leaves READY false, prevents bank execution and enters canonical
lockout or the resident terminal sink. Reset is the recovery boundary.

Pin every consumed source/generator/header/tool/SDK/linker input and exact flags.
Use the existing [LLVM-MOS lock](../../toolchain/f65_toolchain.lock.json);
do not change compiler or ABI flags. Any future post-link descriptor sealing
must prove unchanged outside bytes, addresses and extents and retain raw/sealed
identities; the earlier one-link descriptor protocol may inform that separately
reviewed recipe. No artifact is generated or sealed as a target here.
Runtime CRC identifies current bytes; it does not prove arbitrary transport
delivered fresh bytes. Direct-PRG length/structure and later transport acceptance
remain distinct.

## One reconciled feasibility calculation

The [published candidate record](../evidence/flight-demo/2026-10-25-m2-guard-evidence-publication/record.json)
identifies the historical diagnostic by PRG SHA-256
`10c6b083bd37392b8177d3211035a76c599894aa46bb11ff4a18851e97dab6e1`
and runtime inventory
`d5fce59c011225643d27d884454c7b7982e7a99dfbd4e1af598a4a4fb200a245`.
It reports resident 26750, limit 24575, deficit 2175, compiler scratch 77 and
reserve zero. These are that exact historical candidate's reported results,
not measurements of current main. Main contains no minimum executable,
resumable minimum functions or active bank implementation. No relink was done.

| Reference calculation | Bytes |
| --- | ---: |
| Historical resident | 26750 |
| Reference selected nine bodies | 4374 |
| Conditional resident after removing all nine bodies | 22376 |
| Resident ceiling | 24575 |
| Conditional gross headroom | 2199 |
| Minimum new descriptor/readback/control data | 363 |
| Conditional resident including that minimum | 22739 |
| Remaining allowance for ALL other resident costs | 1836 |
| Reference bank bodies plus 16-byte header | 4390 |
| Remaining 8192-byte bank capacity before other bank costs | 3802 |

**The 2199 figure is headroom after the original deficit, not gross code
recovery. The 363 figure is minimum DATA, not total banking overhead.**
4374−2175=2199; 2199−363=1836. If 2199 were instead gross removal,
26750−2199+363=24914: still 339 bytes oversized before code costs.
That interpretation is not the one in the hash-verified informing ledger.

Let R be all additional resident costs beyond the 363-byte data minimum and
the assumed removal of all nine reference bodies. Conditional fit requires
R ≤ 1836. R includes gateway and per-call signature code, typed trampolines,
normal restoration, boot/copy/CRC loader, additional fault/lockout code,
extra constants, padding, compiler scratch changes, unavoidable duplication
and changed code generation. Do not assume any of these is zero. The
[accounting input](../evidence/flight-demo/2026-10-27-m2-residency-feasibility/accounting.json)
lists each unpriced term. Added stack use is separately bounded inside the
existing 256/4096-byte envelopes and charged to actual owner peaks.

P2 per-call signature verification is now mandatory; its resident code,
additional storage if any, stack and timing increments are **unmeasured**.
The 363-byte minimum is retained; the true overhead is 363 + R, not 363.
No numeric signature surcharge is fabricated and no 1836-byte fit is claimed.
The older nine-body figures were independently matched to their sealed draft
identities, not remeasured against a surviving executable/map. Changed LTO,
retained clones/helpers or padding can invalidate the removal assumption.

At maximum load, [$2001,$A000) is 32767 bank-0 component bytes, plus
8192 staging and 8192 run bank = 49151. Do not add the resident span again.
At runtime, resident-plus-bank envelopes total 32767. Both figures exclude
separately charged stack/base-page/vectors/results/displays/Color RAM/ROM backup
and other live owners. Neither is a complete machine high-water or permission
to use those excluded resources.

**Feasibility: arithmetic has a conditional 1836-byte allowance; complete
banked fit and service remain UNPROVEN. Implementation is NOT ADMITTED.**
There is no measured banked recovery, complete predicted overhead or executable
source identity on main to justify admitting the conditional prototype.
The legal placement decision is also pending. This is a stop at those gates,
not proof that banking can never fit and not a new size-optimization campaign.

## Stack, service, ABI and next step

The historical unbanked diagnostic reports hardware stack 50/256 including
IRQ/NMI, software 127/4096, separate trap 3 and static scratch 77. These remain
reported historical bounds only. New gateway frames, saved P/registers, helper
closure, boot failures, IRQ/NMI and terminal paths require whole-program proof;
no average, guessed increment or inherited PASS admits a banked build.

All eight exact linked dispatch slots, begin/service/commit, guard/clock,
calls/returns, signature reads, restoration, pending IRQ and NMI must be
bounded again. The published unbanked quiet-plus-largest-slot value is 9794
against clock period >9892 in its pinned Xemu profile. Those values provide no
automatic bank-call timing allowance. Unknown/zero budgets refuse dispatch;
no skipped/merged ticks or change to 100 Hz / 21-stage order is allowed.

After review, the smallest next engineering checkpoint is a new,
source-complete minimum-renderer baseline from integrated Git code, preserving
the approved nine-segment behavior and precision, with an explicit new identity.
Do not represent missing former source as recovered. Review and publish that
coherent source checkpoint before stacking a bank prototype on it. In parallel
design terms, RF-D1–RF-D3 need a focused coordinated adoption if banking is
selected. Actual banking work can proceed only with a defensible complete
budget and newly verified source baseline.

If banking is declined or cannot meet the complete budget, the bounded
configuration alternative to evaluate is a simpler immutable-glyph numeric HUD
in place of custom pixel-font composition, preserving all required telemetry,
camera, nine segments and complete-generation coherence. This requires a fresh
display/resource decision and measurement; no 2175-byte saving is asserted,
and it is not implemented here. Do not reduce precision, omit required scene
content, freeze the camera or borrow another owner's memory as a fallback.

Before direct-PRG Xemu: integrate the reviewed source/contracts, link the entire
mutable-camera executable, prove resident ≤24575, bank ≤8192, no owner overlap
or reserve use, early startup, complete stacks, physical mapping/signature
fault cases and all service bounds. Then obtain exact executable execution
authorization and run PAL/NTSC visuals/camera/tick/fault checks. No old diagnostic
PASS authorizes a new banked image or full M2/Graphics acceptance.

## Validation and handoff

Run the local read-only calculation check from this checkout:

```text
python3 -B docs/evidence/flight-demo/2026-10-27-m2-residency-feasibility/validate.py
git diff --check
```

The check verifies pinned Git inputs, manifest bytes, reference arithmetic,
range non-overlap, honest unknown costs and fail-closed prototype admission.
It is **design/static verification only**. Signature negative cases (missing,
incorrect, unreadable and changed between successive calls) are mandatory
future implementation tests; none is represented as an executed bank call.
[Validation result](../evidence/flight-demo/2026-10-27-m2-residency-feasibility/validation.json)
records the actual local outcome and source-preservation hashes.

Changed paths: this contract/handoff, calculation, its read-only checker/result
and WIP. Current authority, public ABI, active generators/ledgers and engine
source are unchanged. Generated target-artifact status: **not generated**.
Registers/clobbers, CPU-visible/physical allocation, live MAP/B, DMA, clock/
deadlines and IRQ/NMI: **no runtime changes** in this checkpoint; proposed
impacts are specified above and await adoption/proof.

No target compilation/relink, host geometry rerun, emulator, D81, SD or physical
test was run. No accepted evidence was rerun or overwritten. No commit, push,
PR or merge: this newly authored checkpoint awaits founder review. After
acceptance, commit this focused result, push promptly, open its PR, wait for
required CI and founder merge approval, then verify main before another branch.
