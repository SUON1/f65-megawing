#!/usr/bin/env python3
"""Read-only design/accounting validation; never builds or executes a bank."""
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
BASE = "af3b0913c4b73eb6b8add638fb88bdbbae158036"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def conditional_budget_gate(adopted, source_complete, costs, stack, service):
    # Necessary budget precondition only, never executable admission.
    # None is unknown, never a zero-cost estimate or permission to dispatch.
    return (
        adopted
        and source_complete
        and all(value is not None for value in costs)
        and all(value >= 0 for value in costs)
        and sum(costs) <= 1836
        and stack
        and service
    )


def main():
    data = json.loads((HERE / "accounting.json").read_text())
    require(data["baseline"] == BASE, "wrong baseline")
    head = subprocess.check_output(
        ["git", "--no-optional-locks", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    ancestry = subprocess.run(
        ["git", "--no-optional-locks", "merge-base", "--is-ancestor", BASE, head],
        cwd=ROOT, check=False
    )
    require(ancestry.returncode == 0, "unverified baseline ancestry")
    allowed = {
        "WORK_IN_PROGRESS.md",
        "docs/plans/65AERO_M2_RESIDENCY_FEASIBILITY.md",
        *[str((HERE / name).relative_to(ROOT)) for name in
          ["accounting.json", "validate.py", "validation.json"]],
    }
    changed = subprocess.check_output(
        ["git", "--no-optional-locks", "diff", "--name-only", BASE],
        cwd=ROOT, text=True
    ).splitlines()
    require(set(changed) <= allowed, "baseline changed beyond this checkpoint")
    for name, expected in data["git_inputs"].items():
        blob = subprocess.check_output(
            ["git", "--no-optional-locks", "show", BASE + ":" + name], cwd=ROOT
        )
        require(sha(blob) == expected, "Git input identity: " + name)
        require(sha((ROOT / name).read_bytes()) == expected, "modified input: " + name)

    manifest = json.loads((ROOT / "spec/manifests/spec-corpus.json").read_text())
    present = [d for d in manifest["documents"] if d["present"]]
    for doc in present:
        require(sha((ROOT / doc["relative_path"]).read_bytes()) == doc["sha256"],
                "authority identity: " + doc["document_key"])

    reference = data["reference"]
    published = json.loads((ROOT / data["published_record"]).read_text())
    old = published["retained_development_evidence"]
    for key in ["prg_sha256", "resident_bytes", "resident_limit", "deficit_bytes",
                "compiler_scratch_bytes", "hardware_stack_bytes",
                "software_stack_bytes", "trap_stack_bytes", "reserve_bytes"]:
        require(reference[key] == old[key], "reference mismatch: " + key)

    removed = sum(data["reference_bodies"].values())
    minimum = sum(data["new_resident_data_minimum"].values())
    resident = reference["resident_bytes"]
    limit = reference["resident_limit"]
    calculated = {
        "selected_text": removed,
        "reference_deficit": resident - limit,
        "resident_after_reference_removal": resident - removed,
        "gross_headroom": limit - (resident - removed),
        "new_data_minimum": minimum,
        "resident_with_minimum_data": resident - removed + minimum,
        "remaining_overhead_allowance": limit - (resident - removed + minimum),
        "bank_with_header_minimum": removed + data["signature"]["bytes"],
        "bank_remaining_before_other_costs": 8192 - removed - data["signature"]["bytes"],
        "if_2199_were_removal_deficit": resident - 2199 + minimum - limit,
        "boot_component_union_maximum": (0xA000 - 0x2001) + 8192 + 8192,
        "runtime_resident_bank_envelopes": (0x8000 - 0x2001) + 8192,
    }
    require(calculated == data["derived_estimates"], "arithmetic mismatch")
    allocations = data["proposed_physical_ranges"]
    for label, span in allocations.items():
        require(0 <= span[0] < span[1], "invalid span: " + label)
    spans = list(allocations.items())
    for i, (left, a) in enumerate(spans):
        for right, b in spans[i + 1:]:
            require(a[1] <= b[0] or b[1] <= a[0], "overlap: " + left + "/" + right)
    require(allocations["resident"] == [0x2001, 0x8000], "resident ceiling")
    require(allocations["protected_reserve"] == [0x58000, 0x60000], "reserve changed")
    require(reference["reserve_bytes"] == 0, "reserve use")
    require(data["signature"] == {
        "bytes": 16, "format": "ASCII 65M2RUN2 + expected_build_id[0:8]",
        "owner": "protected Platform gateway", "every_invocation": True,
        "after_selection_before_execution": True, "cached_authorization": False,
        "failure": "no bank execution; canonical restoration; sticky fault and reset lockout",
        "negative_cases_required_not_executed": [
            "missing", "incorrect", "unreadable", "changed_between_successive_calls"]
    }, "per-invocation verification contract weakened")
    costs = list(data["unpriced_resident_terms"].values())
    require(all(c is None for c in costs), "unreviewed new cost estimate")
    require(data["effective"] is False and data["prototype_admitted"] is False,
            "unapproved adoption/admission")
    negatives = [
        (False, True, [0], True, True),  # Missing architectural adoption.
        (True, False, [0], True, True),  # Missing source-complete identity.
        (True, True, [None], True, True),
        (True, True, [1837], True, True),
        (True, True, [0], False, True),
        (True, True, [0], True, False),
        (True, True, [-1], True, True),
    ]
    require(all(not conditional_budget_gate(*case) for case in negatives),
            "prototype gate fails open")
    require(conditional_budget_gate(True, True, [1836], True, True),
            "cost-boundary rule inconsistent")
    require(not conditional_budget_gate(False, False, costs, False, False),
            "current state incorrectly admitted")
    result = {
        "static_validation": "PASS",
        "identity": data["identity"],
        "baseline": BASE,
        "pinned_git_inputs": len(data["git_inputs"]),
        "manifest_documents_verified": len(present),
        "arithmetic": calculated,
        "fail_closed_negative_cases": len(negatives),
        "signature_cases": "specified only; target/host bank calls NOT RUN",
        "contract_adoption": "PENDING_FOUNDER_DECISIONS",
        "complete_budget": "UNPROVEN",
        "prototype_admission": "NOT_ADMITTED",
        "target_fit": "NOT_BUILT",
        "changed_stack_map_service": "UNPROVEN",
        "xemu": "NOT_RUN",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
