# Work in Progress

- **Status: READY FOR REVIEW — recovery exit and bounded residency feasibility; prototype NOT ADMITTED.**
- **Baseline/branch:** verified GitHub main `af3b0913c4b73eb6b8add638fb88bdbbae158036`; `codex/65aero-m2-residency-feasibility`. Exact main push CI 40259907202 succeeded. Fresh durable checkout; original dirty checkout untouched.
- **Authority/result:** founder Recovery Exit directive; [new contract, decisions and handoff](docs/plans/65AERO_M2_RESIDENCY_FEASIBILITY.md). Identity `65AERO-M2-RESIDENCY-FEASIBILITY-1`; not adopted. Model cost is unconstrained; target limits remain unchanged.
- **Accounting:** historical diagnostic 26750 / 24575, deficit 2175. Reference body removal 4374 leaves gross headroom 2199; 363 minimum new DATA leaves 1836 for all remaining costs. Signature/gateway/loader/stack/service costs are unmeasured; actual fit UNPROVEN. See [calculation and static result](docs/evidence/flight-demo/2026-10-27-m2-residency-feasibility/accounting.json).
- **Required decisions:** RF-D1 code placement exception; RF-D2 private protected gateway; RF-D3 reset-only landing/staging leases. No public ABI, current authority or active generated contract changed.
- **Recovery disposition:** old packet incomplete/unadopted: historical 22/37 SHA-verified, 15 not verified recoverable; eight old checkouts NOT VERIFIED at Git-worktree tier. No new recovery or reconstruction. No full preservation PASS.
- **Next:** founder review of this focused checkpoint; then prompt publication after acceptance. A new source-complete minimum renderer and adopted bounded contracts are prerequisites for a costed bank prototype, not recovery of the old packet.
- **Stop:** no implementation, target relink, Xemu, D81, SD, physical test, commit/push/PR/merge. Historical evidence and unrelated paths preserved within the stated verification limits.
